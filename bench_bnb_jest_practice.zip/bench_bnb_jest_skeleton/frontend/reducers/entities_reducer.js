import { combineReducers } from 'redux';

import benches from './benches_reducer';

export default combineReducers({
  benches,
});
