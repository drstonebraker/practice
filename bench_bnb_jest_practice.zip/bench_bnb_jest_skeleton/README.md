# BenchBnB- Frontend Tests

Useful Docs:
* http://redux.js.org/docs/recipes/WritingTests.html
* https://facebook.github.io/jest/docs/en/expect.html
* http://airbnb.io/enzyme/docs/api/
* https://facebook.github.io/jest/docs/en/mock-functions.html
* https://www.npmjs.com/package/react-mock-router
